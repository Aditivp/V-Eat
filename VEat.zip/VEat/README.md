# VEat

#Working of App.

https://github.com/PulkitGiddu/VEat/assets/101356458/517c63df-a93a-48bb-a25a-f3ec56b697f4
